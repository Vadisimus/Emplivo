const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const base = 'http://127.0.0.1:8084/';

(async () => {
  const browser = await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  const issues=[],external=[],writes=[];
  const context=await browser.newContext({viewport:{width:1440,height:1000}});
  const page=await context.newPage();
  page.on('pageerror',e=>issues.push(e.message));
  context.on('request',r=>{if(!r.url().startsWith(base)&&!r.url().startsWith('data:'))external.push(r.url());if(r.method()!=='GET')writes.push(r.url());});
  try {
    await page.goto(base);
    await page.evaluate(()=>document.fonts.ready);
    assert.equal(await page.locator('.job-grid .job-card').count(),4);
    await page.locator('#hero-query').fill('тренер');
    await page.locator('#hero-city').selectOption('Київ');
    await page.locator('#hero-search button').click();
    await page.waitForURL('**/#catalog?**');
    assert.equal(await page.locator('#catalog-list .job-card').count(),1);
    await page.locator('#catalog-list .save-button').click();
    assert.equal(await page.locator('#catalog-list .save-button').getAttribute('aria-pressed'),'true');
    await page.reload();
    assert.equal(await page.locator('#catalog-list .save-button').getAttribute('aria-pressed'),'true');
    await page.locator('[data-action=reset-filters]').first().click();
    assert.equal(await page.locator('#catalog-list .job-card').count(),6);
    await page.locator('[data-filter=sector][value=beauty]').check();
    assert.equal(await page.locator('#catalog-list .empty-state').count(),1);
    await page.locator('[data-action=alert]').last().click();
    await page.locator('#alert-form input').fill('Beauty — Kyiv');
    await page.locator('#alert-form button').click();
    assert.equal(await page.locator('#dialog').isVisible(),false);
    assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('ec-alerts')).length),1);
    await page.locator('[data-action=reset-filters]').first().click();
    await page.locator('[data-filter=sort]').selectOption('salary');
    assert.match(await page.locator('#catalog-list .job-card').first().textContent(),/Wellness-менеджер/);
    await page.locator('#catalog-list [data-action=details]').first().click();
    await page.locator('#dialog [data-action=apply]').click();
    await page.locator('#application-form [name=name]').fill('Тестовий Кандидат');
    await page.locator('#application-form [name=email]').fill('candidate@example.test');
    await page.locator('#application-form [name=phone]').fill('+380000000001');
    await page.locator('#application-form [type=submit]').click();
    await page.locator('#cv-upload').setInputFiles({name:'invalid.exe',mimeType:'application/octet-stream',buffer:Buffer.from('example')});
    assert.equal(await page.locator('#file-error').isVisible(),true);
    await page.locator('#application-form [type=submit]').click();
    assert.equal(await page.locator('#cv-upload').count(),1);
    await page.locator('#cv-upload').setInputFiles({name:'demo.pdf',mimeType:'application/pdf',buffer:Buffer.from('%PDF-1.4\nDEMONSTRATION\n')});
    await page.locator('#application-form [data-action=application-back]').click();
    assert.equal(await page.locator('#application-form [name=name]').inputValue(),'Тестовий Кандидат');
    await page.locator('#application-form [type=submit]').click();
    await page.locator('#application-form [type=submit]').click();
    await page.locator('#application-form [name=consent]').check();
    await page.locator('#application-form [type=submit]').click();
    assert.match(await page.locator('.success-panel').textContent(),/не надсилалися/);
    assert(!await page.evaluate(()=>JSON.stringify(localStorage).includes('candidate@example.test')));
    await page.locator('[data-action=close]').first().click();

    await page.goto(base+'#employers');
    await page.locator('#main [data-action=brief]').click();
    await page.locator('#brief-form [name=company]').fill('Demo spa');
    await page.locator('#brief-form [name=location]').fill('Kyiv');
    await page.locator('#brief-form [type=submit]').click();
    await page.locator('#brief-form [name=role]').fill('Spa therapist');
    await page.locator('#brief-form [name=start]').fill('Next month');
    await page.locator('#brief-form [type=submit]').click();
    await page.locator('#brief-form [name=name]').fill('Demo Employer');
    await page.locator('#brief-form [name=email]').fill('employer@example.test');
    await page.locator('#brief-form [type=checkbox]').check();
    await page.locator('#brief-form [type=submit]').click();
    assert.match(await page.locator('.success-panel').textContent(),/не заброньовано/);
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('#dialog').isVisible(),false);

    await page.goto(base+'#employer-dashboard');
    await page.locator('[data-action=new-job]').click();
    for (const [key,value] of Object.entries({title:'Demo test therapist',company:'Example employer',min:'40000',max:'30000'}))await page.locator(`#new-job-form [name=${key}]`).fill(value);
    await page.locator('#new-job-form [type=submit]').click();
    assert.equal(await page.locator('#job-error').isVisible(),true);
    await page.locator('#new-job-form [name=max]').fill('50000');
    await page.locator('#new-job-form [type=submit]').click();
    assert.match(await page.locator('#main').textContent(),/Demo test therapist/);
    await page.locator('[data-pipeline=a]').selectOption('interview');
    assert.match(await page.locator('.pipeline-col').last().textContent(),/Кандидат A/);

    await page.goto(base+'#home');
    await page.locator('#home-tab-all').focus();
    await page.keyboard.press('ArrowRight');
    assert.equal(await page.locator('#home-tab-spa').getAttribute('aria-selected'),'true');
    assert.equal(await page.locator('#home-job-grid .job-card').count(),3); // includes the local demo advertisement
    await page.locator('[data-action=language]').click();
    assert.equal(await page.locator('html').getAttribute('lang'),'en');
    assert.match(await page.locator('h1').textContent(),/People who help/);
    await page.locator('[data-action=language]').click();

    for(const width of [360,390,768,1024,1440]) {
      await page.setViewportSize({width,height:900});
      for(const route of ['home','catalog','employers','account','employer-dashboard','components']) {
        await page.goto(base+'#'+route);
        assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`Horizontal overflow: ${route} at ${width}`);
      }
    }
    await page.setViewportSize({width:390,height:844});
    await page.goto(base+'#catalog');
    await page.locator('[data-action=filters]').click();
    assert.equal(await page.locator('#filter-panel').isVisible(),true);
    await page.locator('[data-filter=sector][value=spa]').check();
    assert.equal(await page.locator('#catalog-list .job-card').count(),3);
    await page.locator('[data-action=menu]').click();
    assert.equal(await page.locator('#header-navigation').isVisible(),true);

    const reduced=await browser.newContext({reducedMotion:'reduce'});
    const rp=await reduced.newPage();await rp.goto(base);
    assert.equal(await rp.locator('.hero-media>svg').evaluate(el=>getComputedStyle(el).animationName),'none');
    await reduced.close();
    assert.deepEqual(issues,[]);
    assert.deepEqual(external,[],'Runtime must not call external services');
    assert.deepEqual(writes,[],'Prototype must not submit data');
    console.log('PASS: search, filters, sorting, persistence, empty state, local alerts, CV validation, preserved steps, demo application, employer brief, local advertisement, pipeline, keyboard tabs, UA/EN, responsive 360/390/768/1024/1440, reduced motion. Zero external requests or writes.');
    fs.writeFileSync('deliverables/verification.json',JSON.stringify({passed:true,viewportWidths:[360,390,768,1024,1440],externalRequests:0,networkWrites:0,prototypeOnly:true},null,2)+'\n');
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
