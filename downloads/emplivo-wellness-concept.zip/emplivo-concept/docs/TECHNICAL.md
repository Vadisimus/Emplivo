# Технічна специфікація до концепції Emplivo

## 1. Межі реалізації

Це frontend-прототип без backend і без публікації на робочому домені.
HTML/CSS/JS не потребують bundler або npm install. WOFF2 та згенеровані
зображення зберігаються локально; runtime-запитів до CDN немає.

Реалізовано: UK/EN, hash-навігація, живі фільтри, сортування, empty state,
збережені ID вакансій, локальні критерії сповіщень, modal деталей, покроковий
демо-відгук із CV, бриф, локальне демо-оголошення й зміна етапу тестового кандидата.

Не реалізовано: автентифікація, справжня email-розсилка, серверне зберігання CV,
автоматичне бронювання, CMS, ATS sync, платежі, production-аналітика. Інтерфейс
не видає ці можливості за підключені. Не слід публікувати демо як робочу платформу.

## 2. Архітектура, сумісна з поточним хостингом

Поточний сайт використовує PHP-шлюз і Supabase. Найменша міграція:

```text
Browser: responsive UI + accessible enhancements
    ↓ HTTPS, same-origin session / CSRF
PHP 8.3+ application / server-rendered pages
    ├── Existing application gateway, reviewed and retained
    ├── Job search API + HTML detail/category pages
    ├── Employer/candidate authorization
    └── Signed integration webhooks / idempotent writes
         ↓
Supabase PostgreSQL + RLS + private CV storage
    ├── Job and employer records
    ├── Application ownership and status history
    └── Queue/outbox for email, ATS and calendar events
```

Для повного PHP-застосунку доречно обрати підтримувану версію Laravel,
сумісну з наявним PHP, або зберегти компактні PHP-контролери після оцінки команди.
До вибору фреймворку перевірити на тарифі Composer/CLI, cron, document root,
підтримку черг, HTTPS і вихідні з’єднання. Не припускати, що shared hosting
підтримує постійний Node-процес або worker.

Поштові/ATS-задачі, що потребують worker, винести у підтримуваний managed runtime
або виконувати через надійний cron/outbox. Підключення є production-задачею,
а не зміною налаштувань прототипу.

## 3. Модель даних

| Сутність | Основні поля / правила |
|---|---|
| users | auth_id, role; рекрутер/кандидат/роботодавець визначаються сервером |
| employers | legal_name, display_name, verified_at, contacts; не публікувати приватні контакти автоматично |
| employer_members | employer_id, user_id, permission; scoped access |
| jobs | employer_id, status, sector, seniority, city, country, work_format, pay_min/max, currency/unit, gross/net, published_at, valid_through |
| job_translations | job_id, locale, slug, title, description, duties, requirements, benefits |
| candidate_profiles | user_id, preferences, visibility; без публічного індексування |
| cv_files | storage_key, owner_id, MIME, size, scan_status, expires_at; private bucket |
| applications | job_id, candidate_id, CV reference, consent_version, idempotency_key, status |
| application_events | application_id, actor, old/new status, timestamp; audit trail |
| saved_jobs | user_id, job_id; unique pair; гостьові ID зливаються лише після входу |
| alerts | owner/contact reference, criteria, locale, confirmation/disabled status; token hash |
| booking_requests | contact reference, time_zone, requested_at, provider_id, status |
| content | type, locale, slug, draft/published, author/reviewer, dates, evidence reference |
| integration_outbox | event_id, destination, attempts, next_attempt, delivered_at; dedupe |

Реальний зарплатний діапазон потребує мінімуму ≤ максимуму, валюти й періоду.
Оренда місця, дохід самозайнятого фахівця й базова зарплата не є взаємозамінними.
Адреса показується на рівні, погодженому роботодавцем; невідомі поля не вигадуються.

## 4. API та контракти

| Метод / маршрут | Поведінка |
|---|---|
| GET /api/jobs | q, sectors[], city, work_format[], salary range, management, locale, sort, cursor; totals і стабільний порядок |
| GET /api/jobs/{id} | Лише доступна публічна вакансія; статус закриття явно відомий |
| POST /api/applications | Валідація, згода, приватне CV, idempotency key; успіх лише після збереження |
| POST/DELETE /api/saved-jobs/{id} | Поточний кандидат, unique pair |
| POST /api/alerts | Pending confirmation, rate limit, без дублювання; жодного примусового marketing opt-in |
| POST /api/employer/jobs | Авторизований роботодавець → draft; не одразу published |
| PATCH /api/employer/jobs/{id} | Перевірка membership і допустимих полів/переходів |
| POST /api/booking-requests | Запит, не автоматично confirmed |
| POST /api/webhooks/{provider} | Перевірка підпису, replay protection, idempotency |

Помилки мають стабільні коди й field errors: 422 validation, 401 authentication,
403 authorization, 409 conflict, 413 file size, 429 rate limit. Не виводити
стек, секрети або внутрішні адреси. UI зберігає введене в пам’яті для повтору.

## 5. Пошук і UX

- Фільтри відображаються в query string; URL можна поширити або відновити.
- OR усередині напряму; AND між напрямом, містом, форматом, доходом і seniority.
- Позначити семантику зарплатного фільтра: у прототипі max ≥ бажаного мінімуму.
- Пошук без перезавантаження, cancel попереднього запиту й debounce 150–250 ms
  лише для мережевого API. Локальний прототип реагує одразу.
- Для великих масивів: PostgreSQL full text / pg_trgm з індексами, а не
  завантаження всіх вакансій у браузер. Не додавати зовнішній search service без потреби.
- Production: пагінація або «Показати ще» зі звичайними crawlable links.
- Фокус у полі не губиться під час оновлення результатів. Кількість — aria-live polite.
- Сортування зарплати має пояснювати gross/net/period; не змішувати різні валюти
  без прозорої конвертації й timestamp курсу.

## 6. SEO й мультимовність

Робочі сторінки мають SSR/static HTML: title, description, H1, canonical,
hreflang uk/en/x-default, breadcrumbs і sitemap. Довільні комбінації фільтрів
не індексувати масово. Для цінних поєднань — окремі корисні landing pages.

JobPosting — лише на реальній відкритій вакансії з точними даними роботодавця,
описом, original datePosted, локацією, строком закриття за наявності й фактичною
оплатою. Після закриття розмітку прибирати, статус показувати явно.
Вигадані вакансії не отримують JobPosting. Увесь цей прототип має noindex.

Organization, BreadcrumbList, Article — за відповідним вмістом. Для відгуків
враховувати Google review policies: відгуки про власну агенцію на її сайті
не дають права очікувати self-serving review stars; імпортовані Google-відгуки
не агрегувати у власний рейтинг задля rich results.

Переклади — окремі поля контенту й URL, без автоматичних неперевірених перекладів
професійних вимог. Дату публікації не змінювати для штучного «оновлення» вакансії.

## 7. Доступність та motion

Ціль: WCAG 2.2 AA; аудит production обов’язковий, сам прототип не є сертифікацією.

- Контраст звичайного тексту ≥ 4.5:1; великого й UI-індикаторів ≥ 3:1.
- Terracotta не використовувати як дрібний текст на молочному фоні.
- Клавіатура: menu, tablists зі стрілками, native selects, radio/checkbox,
  діалог із focus trap/Escape та поверненням фокусу.
- Явні labels; status/validation повідомлення пов’язані з полями.
- Touch targets: ціль 44×44 px для основних дій; для компактних — мінімальні
  розміри й проміжки за WCAG 2.2.
- Не передавати статус лише кольором. Збереження має aria-pressed.
- Reduced-motion вимикає фон, reveal й масштабування; відео має pause.
- Прокрутка нативна. Магнітне відхилення кнопки, якщо додавати, лише 1–2 px
  для pointer:fine, без зміни hit area й без впливу на клавіатуру.

## 8. Відео, зображення і продуктивність

Поточний постер згенерований для концепції. Перед production отримати
погоджене коротке відео без аудіодоріжки або з muted; autoplay, loop,
playsinline, pause control. Poster доступний одразу; відео lazy-load після
основного контенту, не на save-data/reduced-motion. На слабкій мережі — лише poster.

Бюджети як acceptance targets, не виміряні бізнес-результати:

| Показник | Ціль |
|---|---|
| Core Web Vitals | LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1 на 75-му перцентилі |
| Основний JS | ≤ 150 KB gzip до optional integrations |
| Hero poster | Орієнтир ≤ 250 KB, responsive AVIF/WebP із правами використання |
| Необов’язкове відео | Окреме завантаження; бюджет погодити за реальним asset |
| Іконки | SVG sprite або невеликі Lottie; без блокування першого екрану |
| Шрифти | WOFF2 subset, font-display swap, обмежений preload |

Для прототипу один atlas зручно показує чотири ілюстрації. Для production
потрібні окремі responsive crops/формати й srcset, а не доставка великого atlas
кожному екрану. Це явна оптимізаційна задача перед запуском.

## 9. Безпека й дані

- Серверна авторизація на кожен запит; employer_id не брати на віру з форми.
- RLS: кандидат бачить лише свої дані; роботодавець — лише вакансії своєї
  організації та доступні заявки; recruiter/admin — окремо обмежені ролі.
- CV — private storage, короткоживучі signed URLs, аудит завантажень,
  content/MIME validation, antivirus/quarantine до доступу персоналу.
- Ліміти розміру 5 MB і типи PDF/DOCX перевіряються також на сервері.
- Session cookies HttpOnly/Secure/SameSite, CSRF, rate limits і захист від enumeration.
- TLS, CSP з точними джерелами, parameterized queries, output escaping,
  secret storage поза публічним коренем і Git. Ніколи не переносити service keys у JS.
- Retention/delete workflow, consent versions, доступ до CV та повідомлень за мінімумом прав.
- Не логувати CV, повні форми, токени чи персональні контакти в аналітику.
- Production backup + перевірений restore, staging без реальних CV.

## 10. Інтеграції

| Інтеграція | Передумова | Критерій готовності |
|---|---|---|
| ATS | Обраний провайдер, API scope, mappings і власник даних | Retry/outbox, dedupe, журнал sync, узгоджені статуси |
| CMS | Ролі редакторів, переклади, рев’ю | Draft/review/publish, медіаправа, історія змін |
| Email alerts | Provider, підтвердження домену, unsubscribe | Double opt-in де потрібно, matching, частота й suppression |
| Calendar | Provider, часові пояси, доступність | Підписані webhooks, confirmed/cancelled, без подвійного запису |
| Google Reviews | Реальний profile і дозволений спосіб показу | Джерело, актуальність, коректна атрибуція; без вигаданого рейтингу |
| Analytics | Consent і property, схема events | Backend-confirmed conversions; без PII |

Події: view_job, search_jobs, save_job, begin_application,
application_submitted, employer_enquiry_submitted, job_published,
alert_confirmed, consultation_confirmed. Клік або підготовлений бриф не є
підтвердженою заявкою/бронюванням.

KPI: qualified applications/live job, application completion, qualified employer
leads, confirmed consultations, alert confirmation, time-to-first-qualified
application і time-to-fill за узгодженими визначеннями. Цілі визначити після baseline.

## 11. План розробки

| Етап | Результат | Пріоритет / залежність |
|---|---|---|
| 0 | Дані, медіаправа, послуги, юридичні вимоги, хостинг і вибір інтеграцій | P0, до production |
| 1 | Адаптивна дизайн-система, SSR home/catalog/detail, UK/EN, реальний пошук | P0, підтверджені вакансії |
| 2 | Надійний відгук і приватне CV; employer brief; backend events | P0, auth/storage/consent |
| 3 | Кабінет кандидата, злиття guest saves, alerts і CV lifecycle | P1, email/auth |
| 4 | Employer drafts, moderation, pipeline, ATS sync і CMS | P1, права/інтеграції |
| 5 | Реальні кейси/reviews, calendar, salary guides, конверсійні поліпшення | P2, перевірені джерела |

Перед запуском: end-to-end кандидат/роботодавець, retry/idempotency, авторизація
між організаціями, доступність, mobile widths 360/390/768/1440, error/offline/empty,
закриті вакансії, SEO validation, file security, consent, restore і rollback.
