#!/usr/bin/env python3
"""Render the design handoff and package it with explicit public permissions."""
from pathlib import Path
from html import escape
import re
import zipfile

ROOT=Path(__file__).resolve().parent

def inline(s):
    s=escape(s)
    s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
    return re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s)

def markdown(text):
    out=[];lines=text.splitlines();i=0
    while i<len(lines):
        line=lines[i]
        if not line.strip():i+=1;continue
        if line.startswith('```'):
            code=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
            out.append('<pre><code>'+escape('\n'.join(code))+'</code></pre>');i+=1;continue
        if line.startswith('#'):
            n=len(line)-len(line.lstrip('#'));out.append(f'<h{n}>'+inline(line[n:].strip())+f'</h{n}>');i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):
                row=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[:\- ]+',c) for c in row):rows.append(row)
                i+=1
            out.append('<div class="table-scroll"><table><thead><tr>'+''.join('<th>'+inline(c)+'</th>' for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(c)+'</td>' for c in row)+'</tr>' for row in rows[1:])+'</tbody></table></div>');continue
        if line.startswith('- ') or re.match(r'^\d+\. ',line):
            ordered=not line.startswith('- ');items=[]
            while i<len(lines) and (lines[i].startswith('- ') or re.match(r'^\d+\. ',lines[i])):
                item=re.sub(r'^(?:- |\d+\. )','',lines[i]);i+=1
                while i<len(lines) and lines[i].startswith('  '):item+=' '+lines[i].strip();i+=1
                items.append('<li>'+inline(item)+'</li>')
            tag='ol' if ordered else 'ul';out.append('<'+tag+'>'+''.join(items)+'</'+tag+'>');continue
        paragraph=[line];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```','- ')) and not re.match(r'^\d+\. ',lines[i]):paragraph.append(lines[i]);i+=1
        out.append('<p>'+inline(' '.join(paragraph))+'</p>')
    return '\n'.join(out)

for name,title in [('CONCEPT','Концепція та структура'),('TECHNICAL','Технічні нотатки')]:
    body=markdown((ROOT/'docs'/f'{name}.md').read_text())
    (ROOT/'docs'/f'{name}.html').write_text(f'''<!doctype html><html lang="uk"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Emplivo · {title}</title><link rel="stylesheet" href="../styles.css"><style>.document{{width:min(980px,calc(100% - 40px));margin:50px auto 100px}}.document h1{{font-size:58px;margin:40px 0}}.document h2{{font-size:40px;margin:55px 0 25px}}.document h3{{font-size:22px;margin:30px 0 15px}}.document p,.document li{{font-size:14px;line-height:1.9;margin:15px 0;color:#53594f}}.document pre{{background:#efece6;padding:25px;border-radius:16px;overflow:auto;font-size:12px}}.document code{{font-size:.9em}}.table-scroll{{overflow:auto;margin:25px 0}}table{{border-collapse:collapse;width:100%;font-size:12px}}th,td{{padding:15px;text-align:left;border-bottom:1px solid #dddcd3;vertical-align:top}}th{{color:#405446;background:#e6ece5}}@media(max-width:600px){{.document h1{{font-size:42px}}.document h2{{font-size:32px}}}}</style><article class="document"><a class="text-link" href="../overview.html">← До матеріалів концепції</a>{body}</article></html>''')

shots=[('hi-fi-home-desktop','Головна · desktop'),('hi-fi-home-mobile','Головна · mobile'),('hi-fi-catalog-desktop','Каталог · desktop'),('hi-fi-catalog-mobile','Каталог · mobile'),('hi-fi-employers-desktop','Роботодавцям · desktop'),('hi-fi-employers-mobile','Роботодавцям · mobile'),('wireframe-home-desktop','Wireframe головної · desktop'),('wireframe-home-mobile','Wireframe головної · mobile'),('wireframe-catalog-desktop','Wireframe каталогу · desktop'),('wireframe-catalog-mobile','Wireframe каталогу · mobile'),('component-library','Бібліотека компонентів'),('application-flow','Покроковий відгук')]
gallery=''.join(f'<a class="handoff-card" href="deliverables/{name}.png"><img src="deliverables/{name}.png" alt="{title}" loading="lazy"><strong>{title}</strong><span>PNG · переглянути повністю →</span></a>' for name,title in shots)
(ROOT/'overview.html').write_text(f'''<!doctype html><html lang="uk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Emplivo · Дизайн-концепція та прототип</title><link rel="stylesheet" href="styles.css"><style>.handoff-hero{{padding:65px 0 45px;max-width:900px}}.handoff-hero h1{{font-size:76px;margin:25px 0}}.handoff-hero>p{{font-size:15px;max-width:650px;margin-bottom:30px}}.handoff-links{{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin:40px 0 60px}}.handoff-links a{{padding:26px;background:var(--cream);border-radius:20px}}.handoff-links h2{{font-size:30px;margin-bottom:15px}}.handoff-links p{{font-size:12px}}.handoff-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin:35px 0 65px}}.handoff-card{{display:block;background:var(--white);border:1px solid var(--line);border-radius:20px;overflow:hidden}}.handoff-card img{{width:100%;height:280px;object-fit:cover;object-position:top;display:block;border-bottom:1px solid var(--line)}}.handoff-card strong{{display:block;margin:20px 22px 4px;font-size:14px}}.handoff-card span{{display:block;margin:0 22px 22px;font-size:11px;color:var(--muted)}}.handoff-proof{{padding:25px;border:1px solid var(--line);border-radius:20px;margin-bottom:65px;line-height:1.9}}@media(max-width:800px){{.handoff-hero h1{{font-size:52px}}.handoff-grid{{grid-template-columns:repeat(2,1fr)}}.handoff-links{{grid-template-columns:1fr}}}}@media(max-width:500px){{.handoff-grid{{grid-template-columns:1fr}}}}</style></head><body><main class="wrap"><section class="handoff-hero"><a class="brand" href="index.html"><img src="assets/mark.svg" width="35" height="35" alt=""><span class="brand-word">EMPLIVO<span class="brand-caption">WELLNESS TALENT · DESIGN CONCEPT</span></span></a><h1>Спокійна естетика.<br><em>Продуманий наступний крок.</em></h1><p>Концепція рекрутингової агенції Wellness, Spa та Fitness: дві аудиторії, одна цілісна система та практичний каталог вакансій.</p><div class="button-row"><a href="index.html#home" class="button button-primary">Відкрити інтерактивний прототип →</a><a href="index.html#catalog" class="button button-secondary">До каталогу вакансій</a></div></section><div class="handoff-links"><a href="docs/CONCEPT.html"><h2>Концепція й сценарії</h2><p>Позиціювання, карта сайту, сценарії кандидата й роботодавця, структура desktop/mobile.</p></a><a href="docs/TECHNICAL.html"><h2>Технічна специфікація</h2><p>Backend, дані й API, CMS/ATS, SEO, безпека, доступність, performance та етапи впровадження.</p></a><a href="index.html#components"><h2>Жива дизайн-система</h2><p>Токени, шрифти, кнопки, поля, картки, стани, tabs, modal і покрокові форми.</p></a></div><p class="eyebrow">DESIGN HANDOFF</p><h2>Макети та wireframes</h2><div class="handoff-grid">{gallery}</div><div class="handoff-proof"><strong>Перевірено у Chromium:</strong> пошук, фільтри, збереження, empty state, покрокові форми, CV validation, демо-оголошення, клавіатура, UA/EN, reduced-motion та ширини 360–1440 px. Зовнішніх runtime-запитів і надсилань даних — нуль.<br><br><strong>Межі концепції:</strong> усі вакансії й роботодавці вигадані. Авторизація, розсилка, CMS, ATS і справжнє бронювання потребують backend-інтеграцій. Фото — концептуальні візуалізації. Робочий сайт не змінювався.</div></main></body></html>''')

output=Path('/workspace/releases/emplivo-wellness-concept.zip')
output.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    for directory in [ROOT]+sorted(p for p in ROOT.rglob('*') if p.is_dir() and '__pycache__' not in p.parts):
        relative=directory.relative_to(ROOT).as_posix()
        name='emplivo-concept/'+('' if relative=='.' else relative+'/')
        info=zipfile.ZipInfo(name);info.create_system=3;info.external_attr=(0o40755<<16)|0x10
        z.writestr(info,b'')
    for item in sorted(ROOT.rglob('*')):
        if not item.is_file() or item.name.startswith('preview-') or item.name.endswith('.zip') or '__pycache__' in item.parts:continue
        info=zipfile.ZipInfo('emplivo-concept/'+item.relative_to(ROOT).as_posix())
        info.create_system=3;info.external_attr=(0o100644<<16);info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,item.read_bytes())
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    assert all('config.php' not in n and 'emplivo-private' not in n for n in z.namelist())
    print('Verified design package:',output,'files:',len(z.namelist()),'bytes:',output.stat().st_size)
