# Emplivo — Wellness Talent

Інтерактивна концепція преміальної рекрутингової агенції: теплий мінімалізм,
шафлієвий акцент, Cormorant Garamond + Inter, адаптивний каталог і дві чіткі
аудиторні лінії — кандидат та роботодавець.

## Перегляд

Почніть з `overview.html` — це презентація пакета з посиланнями на всі матеріали.
Сам прототип — `index.html`. Зручно відкрити папку у VS Code через Live Server
або запустити зі встановленим Python:

```bash
python -m http.server 8084 --bind 127.0.0.1
```

Після цього відкрийте у браузері локальний порт 8084. Відсутній backend:
форми, кабінети й оголошення — демонстрації, без надсилання або публікації даних.

## Матеріали

- `docs/CONCEPT.md` — концепція, карта сайту, сценарії, специфікація екранів.
- `docs/TECHNICAL.md` — архітектура, дані, API, CMS/ATS, безпека, SEO, доступність,
  медіабюджети й план впровадження.
- `deliverables/hi-fi-*.png` — фактичні десктопні та мобільні макети.
- `deliverables/wireframe-*.png` — структурні wireframes головної та каталогу.
- `deliverables/component-library.png` і маршрут `#components` — бібліотека.
- `deliverables/application-flow.png` — стан покрокової анкети.
- `deliverables/verification.json` — короткий звіт перевірки.

## Основні маршрути

`#home`, `#catalog`, `#employers`, `#account`, `#employer-dashboard`, `#cases`,
`#about`, `#privacy`, `#components`. Англійська версія: перемикач EN у хедері.
Wireframe-режим: кнопка у футері або параметр `?wireframe=1` перед фрагментом.

## Редагування

`styles.css` містить токени й компоненти, `app.js` — інтерфейс і сценарії,
`data.js` — явно вигадані приклади вакансій. Усе працює без bundler.
Для automated browser verification потрібні Playwright та Chromium:

```bash
node verify.cjs
node export.cjs
```

Перевірено: живий пошук, фільтри й сортування, порожній стан, local saves,
локальні alert preferences, трикроковий відгук, CV validation, бриф,
створення локального оголошення, pipeline, UA/EN, клавіатура,
responsive 360/390/768/1024/1440, reduced motion. Зовнішніх runtime-запитів і
мережевих записів у тесті — нуль. Це не замінює production accessibility/security audit.

## Медіа й ліцензії

`assets/wellness-atlas.png` — згенеровані концептуальні інтер’єри. Вони не
зображують реальних клієнтів чи роботодавців. Локальні variable fonts отримані
з `@fontsource-variable/inter` і `@fontsource-variable/cormorant-garamond` 5.3.0
зі звіркою SHA512 npm tarballs. Файли ліцензій збережені в `assets/fonts/`.

Справжнє фонове відео та реальні партнерські відгуки потребують погоджених asset.
Публікація на домені, production accounts, ATS, CMS, email і календар не виконувалися.

Примітка перевірки: керований Chrome блокує file:// адміністративною політикою.
Перевірки виконані через локальний HTTP-сервер; рекомендований перегляд — Live Server.
