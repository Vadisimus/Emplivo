const {chromium}=require('playwright');
const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
  for(const mobile of [false,true]){
   const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1440,height:1000},deviceScaleFactor:1,reducedMotion:'reduce'});
   const page=await context.newPage();
   for(const wire of [false,true])for(const route of ['home','catalog']){
    await page.goto('http://127.0.0.1:8084/'+(wire?'?wireframe=1':'')+'#'+route);
    await page.evaluate(()=>document.fonts.ready);
    await page.evaluate(()=>document.querySelectorAll('.reveal').forEach(el=>el.classList.add('in-view')));
    await page.screenshot({path:`deliverables/${wire?'wireframe':'hi-fi'}-${route}-${mobile?'mobile':'desktop'}.png`,fullPage:true,animations:'disabled'});
   }
   await page.goto('http://127.0.0.1:8084/#employers');
   await page.evaluate(()=>document.fonts.ready);await page.evaluate(()=>document.querySelectorAll('.reveal').forEach(el=>el.classList.add('in-view')));
   await page.screenshot({path:`deliverables/hi-fi-employers-${mobile?'mobile':'desktop'}.png`,fullPage:true,animations:'disabled'});
   await context.close();
  }
  const page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
  await page.goto('http://127.0.0.1:8084/#components');await page.evaluate(()=>document.fonts.ready);
  await page.screenshot({path:'deliverables/component-library.png',fullPage:true,animations:'disabled'});
  await page.goto('http://127.0.0.1:8084/#catalog');await page.locator('#catalog-list [data-action=details]').first().click();
  await page.locator('#dialog [data-action=apply]').click();
  await page.screenshot({path:'deliverables/application-flow.png',animations:'disabled'});
  console.log('Exported 12 design deliverables: desktop/mobile hi-fi, wireframes, component library, application state.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
