@echo off
setlocal
title Emplivo Design Update v2
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Deploy-Emplivo.ps1" %*
set "EmplivoExitCode=%ERRORLEVEL%"
echo(
if not "%EmplivoExitCode%"=="0" echo Update failed. See the output above.
pause
exit /b %EmplivoExitCode%
